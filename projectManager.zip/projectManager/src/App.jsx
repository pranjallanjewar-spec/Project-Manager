import { useState, useEffect } from "react";

export default function App() {
  // Load projects from localStorage or start empty
  const [projects, setProjects] = useState(() => {
    const saved = localStorage.getItem("projects");
    return saved ? JSON.parse(saved) : [];
  });

  const [projectName, setProjectName] = useState("");
  const [file, setFile] = useState(null);

  // Save projects to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem("projects", JSON.stringify(projects));
  }, [projects]);

  // Add a new project
  const addProject = (e) => {
    e.preventDefault();
    if (!projectName.trim()) return alert("Enter project name");

    setProjects([
      ...projects,
      {
        id: Date.now(),
        name: projectName,
        status: "Pending",
        fileName: file ? file.name : "No file",
      },
    ]);

    setProjectName("");
    setFile(null);
  };

  // Delete project
  const deleteProject = (id) => {
    setProjects(projects.filter((p) => p.id !== id));
  };

  // Edit project name
  const editProject = (id) => {
    const newName = prompt("Enter new project name");
    if (!newName) return;
    setProjects(projects.map((p) => (p.id === id ? { ...p, name: newName } : p)));
  };

  // Update status
  const updateStatus = (id, newStatus) => {
    setProjects(projects.map((p) => (p.id === id ? { ...p, status: newStatus } : p)));
  };

  return (
    <div className="bg-gray-100 min-h-screen font-sans">
      {/* Header */}
      <header className="bg-blue-600 text-white p-4 text-center text-2xl font-bold">
        Project Manager
      </header>

      <main className="p-6 max-w-5xl mx-auto">
        {/* Upload Project Form */}
        <div className="bg-white p-6 rounded shadow-md mb-6">
          <h2 className="text-2xl font-semibold mb-4">Add New Project</h2>
          <form className="flex flex-col md:flex-row gap-4" onSubmit={addProject}>
            <input
              type="text"
              placeholder="Project Name"
              className="border p-2 rounded flex-1"
              value={projectName}
              onChange={(e) => setProjectName(e.target.value)}
            />
            <input
              type="file"
              className="border p-2 rounded flex-1"
              onChange={(e) => setFile(e.target.files[0])}
            />
            <button
              type="submit"
              className="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded"
            >
              Add Project
            </button>
          </form>
        </div>

        {/* Project List Table */}
        <div className="bg-white p-6 rounded shadow-md">
          <h3 className="text-xl font-semibold mb-4">Projects</h3>
          <div className="overflow-x-auto">
            <table className="min-w-full border border-gray-200">
              <thead className="bg-gray-100">
                <tr>
                  <th className="text-left p-2 border-b">Project Name</th>
                  <th className="text-left p-2 border-b">Status</th>
                  <th className="text-left p-2 border-b">File</th>
                  <th className="text-left p-2 border-b">Actions</th>
                </tr>
              </thead>
              <tbody>
                {projects.map((project) => (
                  <tr key={project.id} className="hover:bg-gray-50">
                    <td className="p-2 border-b">{project.name}</td>
                    <td className="p-2 border-b">
                      <select
                        className="border rounded p-1"
                        value={project.status}
                        onChange={(e) => updateStatus(project.id, e.target.value)}
                      >
                        <option>Pending</option>
                        <option>In Progress</option>
                        <option>Completed</option>
                      </select>
                    </td>
                    <td className="p-2 border-b">{project.fileName}</td>
                    <td className="p-2 border-b">
                      <button
                        className="bg-blue-500 hover:bg-blue-700 text-white py-1 px-3 rounded mr-2"
                        onClick={() => editProject(project.id)}
                      >
                        Edit
                      </button>
                      <button
                        className="bg-red-500 hover:bg-red-700 text-white py-1 px-3 rounded"
                        onClick={() => deleteProject(project.id)}
                      >
                        Delete
                      </button>
                    </td>
                  </tr>
                ))}
                {projects.length === 0 && (
                  <tr>
                    <td colSpan="4" className="p-2 text-center text-gray-500">
                      No projects yet.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </main>
    </div>
  );
}
